<?php

declare(strict_types=1);

namespace TreeChopper;

use pocketmine\plugin\PluginBase;
use pocketmine\event\Listener;
use pocketmine\event\block\BlockBreakEvent;
use pocketmine\event\player\PlayerInteractEvent;
use pocketmine\block\Block;
use pocketmine\block\BlockTypeIds;
use pocketmine\block\VanillaBlocks;
use pocketmine\player\Player;
use pocketmine\world\World;
use pocketmine\math\Vector3;
use pocketmine\item\Item;
use pocketmine\utils\Config;
use jojoe77777\FormAPI\SimpleForm;
use pocketmine\command\Command;
use pocketmine\command\CommandSender;

class Main extends PluginBase implements Listener {

    private Config $playerSettings;

    protected function onEnable(): void {
        $this->getServer()->getPluginManager()->registerEvents($this, $this);
        $this->playerSettings = new Config($this->getDataFolder() . "playerSettings.yml", Config::YAML);
    }

    public function onBlockBreak(BlockBreakEvent $event): void {
        $player = $event->getPlayer();
        $block = $event->getBlock();
        
        if ($player->isSneaking() && $this->isLogBlock($block) && $player->hasPermission("treechopper.use")) {
            if ($this->isTreeChopperEnabled($player)) {
                $event->setDrops([]); // Prevent the default drop
                $this->chopTree($block, $player);
            }
        }
    }

    public function onCommand(CommandSender $sender, Command $command, string $label, array $args): bool {
        if ($command->getName() === "tree") {
            if ($sender instanceof Player) {
                if ($sender->hasPermission("treechopper.use")) {
                    $this->openTreeChopperUI($sender);
                } else {
                    $sender->sendMessage("You don't have permission to use this command.");
                }
            } else {
                $sender->sendMessage("This command can only be used in-game.");
            }
            return true;
        }
        return false;
    }

    private function isLogBlock(Block $block): bool {
        return in_array($block->getTypeId(), [
            BlockTypeIds::OAK_LOG,
            BlockTypeIds::SPRUCE_LOG,
            BlockTypeIds::BIRCH_LOG,
            BlockTypeIds::JUNGLE_LOG,
            BlockTypeIds::ACACIA_LOG,
            BlockTypeIds::DARK_OAK_LOG,
            BlockTypeIds::MANGROVE_LOG
        ]);
    }

    private function chopTree(Block $block, Player $player): void {
        $blocks = [$block];
        $world = $block->getPosition()->getWorld();
        $airBlock = VanillaBlocks::AIR();

        while (!empty($blocks)) {
            $current = array_pop($blocks);
            foreach ([
                $current->getSide(0), // Down
                $current->getSide(1), // Up
                $current->getSide(2), // North
                $current->getSide(3), // South
                $current->getSide(4), // West
                $current->getSide(5)  // East
            ] as $side) {
                if ($this->isLogBlock($side)) {
                    $blocks[] = $side;
                }
            }
            $drops = $current->getDrops($player->getInventory()->getItemInHand());
            foreach ($drops as $drop) {
                $world->dropItem($current->getPosition(), $drop);
            }
            $world->setBlock($current->getPosition(), $airBlock);
        }
    }

    private function isTreeChopperEnabled(Player $player): bool {
        return $this->playerSettings->get($player->getName(), true);
    }

    private function setTreeChopperEnabled(Player $player, bool $enabled): void {
        $this->playerSettings->set($player->getName(), $enabled);
        $this->playerSettings->save();
    }

    private function openTreeChopperUI(Player $player): void {
        $form = new SimpleForm(function (Player $player, ?int $data) {
            if ($data !== null) {
                switch ($data) {
                    case 0:
                        $this->setTreeChopperEnabled($player, true);
                        $player->sendMessage("TreeChopper enabled!");
                        break;
                    case 1:
                        $this->setTreeChopperEnabled($player, false);
                        $player->sendMessage("TreeChopper disabled!");
                        break;
                }
            }
        });

        $form->setTitle("TreeChopper Settings");
        $form->setContent("Enable or disable TreeChopper.");
        $form->addButton("Enable");
        $form->addButton("Disable");
        $player->sendForm($form);
    }
}
